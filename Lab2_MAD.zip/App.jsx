

import React from 'react';
import ToDoList from './ToDoList'; // Import ToDoList component
import ToDoForm from './ToDoForm'; // Import ToDoForm component

function App() {
  return (
    <SafeAreaView>
      {/*ToDoList*/}
      <ToDoList />

      {/*ToDoForm*/}
      <ToDoForm />
    </SafeAreaView>
  );
}
