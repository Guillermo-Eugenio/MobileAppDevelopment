

// ToDoList

import React from 'react';
import { ScrollView, Pressable, View, Text, StyleSheet, } from 'react-native';

const ToDoList = () => {
  return (
    <ScrollView>
      <Pressable>

        <View style={[styles.command, styles.completed]}>
          <Text style={styles.commandText}>Do laundry</Text>
        </View>

      </Pressable>
      
      <Pressable>
        <View style={[styles.command]}>
          <Text style={styles.commandText}>Go to gym</Text>
        </View>

      </Pressable>
      <Pressable>

        <View style={[styles.command, styles.completed]}>
          <Text style={styles.commandText}>Walk dog</Text>
        </View>

      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  command: {
    padding: 12,
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },

  completed: {
    backgroundColor: 'blue',
  },
  commandText: {
    fontSize: 16,
  },
});

export default ToDoList;

