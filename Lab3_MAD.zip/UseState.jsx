

import React, { useState } from 'react';
import ToDoList from './ToDoList'; // Import ToDoList component


function App() {

 const [tasks] = useState([
    'Do laundry',
    'Go to gym',
    'Walk dog'
  ]);

  return (
    <view className="App">

      {/* Passing the tasks array to ToDoList component */}
      
      <ToDoList tasks= {tasks} />
    </view>
  );
}

export default App;


