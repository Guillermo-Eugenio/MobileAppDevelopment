

import React from 'react';

function ToDoList ({ tasks }) {
  return (
    
    <view className="ToDoList">

      <h2>Tasks</h2>
      <ol>

        {/* Mapping tasks array and display it in list item */}
        {tasks.map((task, index) => (

          <li key={index}>{task}</li>

        ))}

      </ol>
    </view>
  );
}

export default ToDoList;



