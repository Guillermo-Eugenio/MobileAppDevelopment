

import React from 'react';
import ToDoList from './ToDoList'; // Import ToDoList component
import ToDoForm from './ToDoForm'; // Import ToDoForm component

function App() {
    const [tasks, setTasks] = useState([]);
    const [taskText, setTaskText] = useState('');
  
    const addTask = () => {
      if (taskText.trim() === '') {
        Alert.alert('Error', 'Please enter a valid task.');
        return;
      }
  
      if (tasks.some((task) => task.toLowerCase() === taskText.toLowerCase())) {
        Alert.alert('Error', 'Task already exists.');
        return;
      }
  
      setTasks([...tasks, taskText]);
      setTaskText('');
    };
  
    return (
      <View style={styles.container}>
        <ToDoForm
          taskText={taskText}
          setTaskText={setTaskText}
          addTask={addTask}
        />
        <FlatList
          data={tasks}
          renderItem={({ item }) => <TaskItem task={item} />}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
    );
  };
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 35,
    },
  });
  
  export default App;
